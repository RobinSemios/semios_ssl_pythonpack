======
easter
======
.. automodule:: dateutil.easter
   :members:
   :undoc-members:
