def add(a, b):
    return a + b

def sub(a, b):
    return a - b
