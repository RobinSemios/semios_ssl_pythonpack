import sys

def test_writelines():
    sys.stdout.writelines(["line1\n", "line2\n"])
