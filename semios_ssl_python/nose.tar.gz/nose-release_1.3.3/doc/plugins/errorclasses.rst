.. automodule :: nose.plugins.errorclass

Error class methods
-------------------

.. autoclass :: nose.plugins.errorclass.ErrorClassPlugin
   :members:
