Isolate: protect tests from (some) side-effects
-----------------------------------------------

.. autoplugin :: nose.plugins.isolate